package com.example.healty_quizz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
